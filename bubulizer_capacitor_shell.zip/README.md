# BUBULIZER Kidney Triage — Capacitor Native Shell (iOS/Android)

This project wraps your **offline-first PWA** into a **native shell** you can submit via App Store / Play Store (through your own developer accounts).

## 0) Requirements
- Node.js 18+
- Xcode (for iOS builds)
- Android Studio (for Android builds)

## 1) Install dependencies
```bash
cd bubulizer-capacitor-shell
npm install
```

## 2) Initialize Capacitor (one-time)
```bash
npm run cap:init
```

## 3) Add iOS platform
```bash
npm run cap:add:ios
npm run cap:sync
npm run cap:open:ios
```

## 4) Add Android platform (optional)
```bash
npm run cap:add:android
npm run cap:sync
npm run cap:open:android
```

## 5) App icons & splash screens (recommended, store-ready)
Capacitor's easiest route is:
```bash
npx @capacitor/assets generate --iconBackgroundColor '#111111' --iconBackgroundColorDark '#111111'
```
Then sync again:
```bash
npm run cap:sync
```

You already have:
- iOS splash set zip: `bubulizer_splash_set.zip`
- Android adaptive + marketing set zip: `bubulizer_android_adaptive_splash_set.zip`

Unzip and replace generated assets if you want your exact logo sizing.

## 6) “Medical / safety” compliance (critical)
This app is **educational decision-support**, not a medical device.
- Add the disclaimer screen on first launch (recommended in your web app logic).
- Avoid “diagnose / prescribe” language in store listing.
- Do NOT store identifiable patient data unless you have a compliant backend and proper consent.

## 7) App Store submission notes (iOS)
In Xcode:
- Set Bundle Identifier: `com.bubulizer.kidneytriage`
- Set Version / Build
- Provide Privacy Nutrition Labels
- Provide a “Medical Disclaimer” in-app + listing

## 8) Local development
Run:
```bash
npm start
```
If you want the native shell to load from local server during dev, uncomment `server.url` in `capacitor.config.ts` and re-sync.
